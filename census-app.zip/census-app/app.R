library(shiny)
library(maps)
library(mapproj)

# load the data ----
counties <- readRDS("Data/counties.rds")

# source for helper functions ---- 
source("helpers.R")


# Define UI ----
ui <- fluidPage(
  titlePanel("CensusVis"),
  
  sidebarLayout(
    sidebarPanel(
      helpText("create demographic maps with information from the 2010 US census"),
      
      br(),
      
      selectInput("var", "Choose a variable to dispaly",
                 choices = c("percent white", 
                             "percent black",
                             "percent asian",
                             "percent hispanic"), 
                             selected = "percent white"),
      sliderInput("range", "Range of interest",
                  min = 0, max = 100, value = c(0, 100))
      
    ),
    
    mainPanel(
      plotOutput("maps")
    )
  )
 )


# Define server logic ----
server <- function(input, output) {
  output$maps <- renderPlot({
    data <- switch (input$var,
                    "percent white" = counties$white,
                    "percent black" = counties$black,
                    "percent asian" = counties$asian,
                    "percent hispanic" = counties$hispanic)
    color <- switch (input$var,
                     "percent white" = "darkgreen",
                     "percent black" = "black",
                     "percent asian" = "darkred",
                     "percent hispanic" = "purple")
    legend <- switch (input$var,
                      "percent white" = "% whites",
                      "percent black" = "% blacks",
                      "percent asian" = "% asians",
                      "percent hispanic" = "% hispanics")
    
    
    percent_map(data, color, legend, input$range[1], input$range[2] )
    
  })
}

# Run the app ----
shinyApp(ui = ui, server = server)
